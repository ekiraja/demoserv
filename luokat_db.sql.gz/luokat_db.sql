-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 20.01.2020 klo 01:09
-- Palvelimen versio: 5.6.34
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `luokat_db`
--

-- --------------------------------------------------------

--
-- Rakenne taululle `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `nimi` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `puhelin` varchar(15) NOT NULL,
  `luotu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Rakenne taululle `kouluttajat`
--

CREATE TABLE `kouluttajat` (
  `id` int(11) NOT NULL,
  `nimi` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `puhelin` varchar(15) NOT NULL,
  `oppi_aine` varchar(255) NOT NULL,
  `luotu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vedos taulusta `kouluttajat`
--

INSERT INTO `kouluttajat` (`id`, `nimi`, `email`, `password`, `puhelin`, `oppi_aine`, `luotu`) VALUES
(1, 'Annika Caselius', 'annika.caselius@taitotalo.fi', 'huonosalasana', '020 461 1351', 'Tutkintovastaava Front end', '2020-01-13 17:33:55'),
(3, 'Kari Vikman', 'rootkari.vikman@taitotalo.fi', 'MDIwIDc0NiAxMjA3', '020 746 1207', 'kouluttaja, tutkinto- ja koulutusprojektivastava ICT-alalla', '2020-01-14 16:08:27'),
(13, 'Eki Rajamäki', 'posti@ekin.fi', 'dXNidw==', '04 03721 879', 'Testaaja hyypiö', '2020-01-16 18:30:01'),
(15, 'Eki Koe', 'rooterwew', 'dXNidw==', '0403721879', 'asdfsadfasd', '2020-01-18 07:49:44');

-- --------------------------------------------------------

--
-- Rakenne taululle `kurssit`
--

CREATE TABLE `kurssit` (
  `id` int(11) NOT NULL,
  `nimi` varchar(255) NOT NULL,
  `koulutus_ala` varchar(255) NOT NULL,
  `luotu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vedos taulusta `kurssit`
--

INSERT INTO `kurssit` (`id`, `nimi`, `koulutus_ala`, `luotu`) VALUES
(1, 'web4', 'Datanomi frontend', '0000-00-00 00:00:00'),
(2, 'web3', 'Datanomi frontend', '2020-01-18 17:33:02');

-- --------------------------------------------------------

--
-- Rakenne taululle `tilat`
--

CREATE TABLE `tilat` (
  `id` int(11) NOT NULL,
  `nimi` varchar(15) NOT NULL,
  `paikat` tinyint(2) NOT NULL,
  `luotu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vedos taulusta `tilat`
--

INSERT INTO `tilat` (`id`, `nimi`, `paikat`, `luotu`) VALUES
(1, 'Lab518', 30, '0000-00-00 00:00:00'),
(2, 'Lab519', 16, '0000-00-00 00:00:00'),
(3, 'Lab516', 15, '2020-01-16 19:33:00'),
(4, '551', 10, '2020-01-16 19:44:42'),
(5, 'Lab517', 16, '2020-01-16 20:17:01'),
(6, '505', 16, '2020-01-16 20:23:00'),
(7, '545', 22, '2020-01-16 20:31:37'),
(8, '549', 18, '2020-01-18 07:53:08');

-- --------------------------------------------------------

--
-- Näkymän vararakenne `tila_view`
-- (See below for the actual view)
--
CREATE TABLE `tila_view` (
`id` int(11)
,`varaus` text
,`kurssi` varchar(255)
,`aihe` varchar(255)
,`tila` varchar(15)
,`kouluttaja` varchar(255)
);

-- --------------------------------------------------------

--
-- Rakenne taululle `varaus`
--

CREATE TABLE `varaus` (
  `id` int(11) NOT NULL,
  `oppi_aine` varchar(255) NOT NULL,
  `kouluttaja_id` int(11) NOT NULL,
  `kurssi_id` int(11) NOT NULL,
  `tila_id` int(11) NOT NULL,
  `varaus` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vedos taulusta `varaus`
--

INSERT INTO `varaus` (`id`, `oppi_aine`, `kouluttaja_id`, `kurssi_id`, `tila_id`, `varaus`) VALUES
(1, 'Ohjelmiston prototyypin toteuttaminen / NÄYTTÖ ja ARVIONTI ap', 1, 1, 1, '2020-01-15'),
(2, 'Ohjelmiston prototyypin toteuttaminen / NÄYTTÖ ja ARVIONTI ap ja ip ', 1, 1, 1, '2020-01-16'),
(3, 'Ohjelmiston prototyypin toteuttaminen / NÄYTTÖ ja ARVIONTI', 3, 1, 4, '2020-01-20');

-- --------------------------------------------------------

--
-- Näkymän rakenne `tila_view`
--
DROP TABLE IF EXISTS `tila_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tila_view`  AS  select `varaus`.`id` AS `id`,`varaus`.`varaus` AS `varaus`,`kurssit`.`nimi` AS `kurssi`,`varaus`.`oppi_aine` AS `aihe`,`tilat`.`nimi` AS `tila`,`kouluttajat`.`nimi` AS `kouluttaja` from (((`varaus` join `kouluttajat` on((`varaus`.`kouluttaja_id` = `kouluttajat`.`id`))) join `kurssit` on((`varaus`.`kurssi_id` = `kurssit`.`id`))) join `tilat` on((`varaus`.`tila_id` = `tilat`.`id`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kouluttajat`
--
ALTER TABLE `kouluttajat`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `nimi` (`nimi`);

--
-- Indexes for table `kurssit`
--
ALTER TABLE `kurssit`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nimi` (`nimi`);

--
-- Indexes for table `tilat`
--
ALTER TABLE `tilat`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nimi` (`nimi`);

--
-- Indexes for table `varaus`
--
ALTER TABLE `varaus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kouluttaja_id` (`kouluttaja_id`),
  ADD KEY `kurssi_id` (`kurssi_id`),
  ADD KEY `tila_id` (`tila_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kouluttajat`
--
ALTER TABLE `kouluttajat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `kurssit`
--
ALTER TABLE `kurssit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tilat`
--
ALTER TABLE `tilat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `varaus`
--
ALTER TABLE `varaus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Rajoitteet vedostauluille
--

--
-- Rajoitteet taululle `varaus`
--
ALTER TABLE `varaus`
  ADD CONSTRAINT `varaus_ibfk_1` FOREIGN KEY (`kouluttaja_id`) REFERENCES `kouluttajat` (`id`),
  ADD CONSTRAINT `varaus_ibfk_2` FOREIGN KEY (`kurssi_id`) REFERENCES `kurssit` (`id`),
  ADD CONSTRAINT `varaus_ibfk_3` FOREIGN KEY (`tila_id`) REFERENCES `tilat` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
